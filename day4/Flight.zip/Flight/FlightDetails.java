package Flight;

public class FlightDetails {

	public void printFlightDetails(Flight flight)
	{
		/* Write code to print the flight information and fare break up*/
	}
}
