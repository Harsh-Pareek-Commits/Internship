package Flight;

/* No International Flyer Tax on these countries, Considering as Free Travel*/
public class FriendlyCountry {

	public static String countries[] =
		{
				"UAE",
				"Nepal",
				"Bhutan",
				"Mauritius",
				"Afganistan",
				"Mangolia",
		};
}
