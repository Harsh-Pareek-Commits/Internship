package Flight;

public class Hault {

	private String airportName;
	private int duration;
	
}
